<?php
/**
 * Created by PhpStorm.
 * User: suwen
 * Date: 2017/10/6
 * Time: 14:43
 */
namespace pc\services\search;

interface SearchInterface{
    public function toStart();
}