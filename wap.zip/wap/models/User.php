<?php
/**
 * Created by PhpStorm.
 * User: Alan
 * Date: 2017/11/18
 * Time: 21:34
 */
namespace  pc\models;

use yii\db\ActiveRecord;

class User extends ActiveRecord
{

}