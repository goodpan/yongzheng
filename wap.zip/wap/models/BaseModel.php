<?php
/**
 * Created by PhpStorm.
 * User: suwen
 * Date: 2017/10/15
 * Time: 11:29
 */


class BaseModel{
    public function getId(){


    }
    public function getAll(){

    }
    public  function getOne(){

    }

}