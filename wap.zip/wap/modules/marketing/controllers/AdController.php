<?php
/**
 * Created by PhpStorm.
 * User: suwen
 * Date: 2017/10/14
 * Time: 14:55
 */
namespace pc\modules\marketing\controllers;

use pc\controllers\BaseController;

/** 广告类
 * Class AdController
 * @package pc\modules\marketing\controllers
 */
class AdController extends BaseController{
    /**
     * Displays homepage.
     *
     * @return mixed
     */
    public function actionIndex()
    {
        echo "ad index";
    }
}