<?php
/**
 * Created by PhpStorm.
 * User: suwen
 * Date: 2017/10/5
 * Time: 19:34
 */
namespace pc\modules\marketing;

/** 营销模块入口
 * Class Marketing
 * @package pc\modules\marketing
 */
class Marketing extends \yii\base\Module {
    public function init() {
        parent::init();
    }
}