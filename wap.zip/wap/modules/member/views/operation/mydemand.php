<?php
/**
 * Created by PhpStorm.
 * User: suwen <suwen@3elephant.com>
 * Date: 2017/11/14 
 * Time: 下午 15:00
 */
$this->title = "我提交的需求";
?>
<?php $this->beginBlock('cssblock')?>
    <link rel="stylesheet" type="text/css" href="/css/member/member.css">
<?php $this->endBlock('cssblock')?>
<div class="my_demand">
		<section class="demand_list">
			<ul>
				<li>
					<a href="">
						<div class="demand_info flex">
							<span class="time">2017-11-09</span>
							<span class="wait">等待处理</span>
						</div>
						<div class="demand_content">
							<p>需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述</p>
						</div>
					</a>
				</li>
				<li>
					<a href="">
						<div class="demand_info flex">
							<span class="time">2017-11-09</span>
							<span class="deal">处理中</span>
						</div>
						<div class="demand_content">
							<p>需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述</p>
						</div>
					</a>
				</li>
				<li>
					<a href="">
						<div class="demand_info flex">
							<span class="time">2017-11-09</span>
							<span class="already">已完成</span>
						</div>
						<div class="demand_content">
							<p>需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述需求概述</p>
						</div>
					</a>
				</li>
			</ul>
		</section>
	</div>