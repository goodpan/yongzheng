<?php
/**
 * Created by PhpStorm.
 * User: suwen <suwen@3elephant.com>
 * Date: 2017/11/14 
 * Time: 下午 15:00
 */
$this->title = "注册协议";
?>
<?php $this->beginBlock('cssblock')?>
<?php $this->endBlock('cssblock')?>
    <div class="pro-main">
        <h2 class="pro-h">IT空间注册协议</h2>
        <div class="pro-con">
        空间注册协议空间注册协议空间注册协议空间注册协议空间注册协议空间注册协议
        </div>
    </div>
<?php $this->beginBlock('jsblock')?>
<script>
   
<?php $this->endBlock('jsblock')?>

