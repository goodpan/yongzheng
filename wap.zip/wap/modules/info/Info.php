<?php
/**
 * Created by PhpStorm.
 * User: suwen
 * Date: 2017/10/5
 * Time: 19:34
 */

namespace wap\modules\info;

class Info extends \yii\base\Module {
    public function init() {
        parent::init();
    }
}