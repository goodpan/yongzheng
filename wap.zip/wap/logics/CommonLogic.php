<?php
/**
 * Created by PhpStorm.
 * User: suwen
 * Date: 2017/10/15
 * Time: 11:15
 */

namespace wap\logics;

class CommonLogic{

}