<?php
/**
 * Created by PhpStorm.
 * User: suwen
 * Date: 2017/10/6
 * Time: 09:45
 */
namespace wap\logics;

/** pc端逻辑层基类
 * Class BaseLogic
 * @package pc\logics
 */
class BaseLogic{

}